export const getAccountId = (address: string, chainId: string) => `${chainId}-${address}`
