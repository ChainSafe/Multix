export const MULTI_PREFIX = 'MULTI'
